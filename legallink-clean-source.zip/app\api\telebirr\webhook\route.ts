import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://rkvqnywbsnxzjtwkgbny.supabase.co';
const SUPABASE_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJrdnFueXdic254emp0d2tnYm55Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIyMzAyNjIsImV4cCI6MjEwNzgwNjI2Mn0.tIdqzeI77ErBFZYrYATO4-cDxO3VOJ4dSRuTM7FMOrg';

// 1. GET: Clean health check
export async function GET() {
  return NextResponse.json({
    service: 'LegalLink Telebirr Webhook Gateway',
    status: 'active',
    protocol: 'C2B / B2C Escrow Listener',
    timestamp: new Date().toISOString(),
  });
}

// 2. POST: Process Telebirr payments safely in a Node.js environment
export async function POST(req: Request) {
  try {
    const body = await req.json();

    const consultationId = body.consultation_id || body.outTradeNo || body.case_id;
    const transactionRef = body.transaction_ref || body.transactionNo || body.txn_ref || `TLB-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
    const amount = Number(body.amount || body.totalAmount || 1500);
    const phone = body.phone_number || body.msisdn || '0905941865';
    const clientName = body.client_name || 'Client';
    const tradeStatus = String(body.status || body.tradeStatus || 'SUCCESS').toUpperCase();
    const paymentStatus = tradeStatus === 'FAILED' ? 'unpaid' : 'escrow_locked';

    // Pure server client with session persistence disabled
    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: { persistSession: false },
    });

    if (consultationId) {
      await supabase
        .from('consultations')
        .update({
          payment_status: paymentStatus,
          payment_method: 'telebirr',
          transaction_ref: transactionRef,
          escrow_amount: amount,
        })
        .eq('id', consultationId);
    }

    await supabase
      .from('escrow_transactions')
      .insert([
        {
          consultation_id: consultationId || null,
          client_name: clientName,
          phone_number: phone,
          payment_channel: 'telebirr',
          amount_etb: amount,
          transaction_ref: transactionRef,
          status: paymentStatus,
        },
      ]);

    return NextResponse.json({
      code: 0,
      message: 'Telebirr webhook processed and escrow secured',
      data: {
        transaction_ref: transactionRef,
        consultation_id: consultationId,
        escrow_status: paymentStatus,
      },
    }, { status: 200 });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown exception';
    return NextResponse.json(
      { code: 500, message: 'Internal Webhook Failure', error: errorMessage },
      { status: 500 }
    );
  }
}